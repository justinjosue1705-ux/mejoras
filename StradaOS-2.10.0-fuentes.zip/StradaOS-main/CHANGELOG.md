# Historial de cambios

Las notas detalladas de cada versión están en [`changelogs/`](changelogs) y en [Releases](../../releases).

## 2.10.0 — Diagnóstico más claro
- Los errores que antes se ignoraban ahora quedan en un registro, y el diagnóstico exportado incluye `errores.txt`.

## 2.9.1 — Arreglo del audio Bluetooth
- Play después de pausar funciona de nuevo con el audio automático.
- Si el sonido no es Bluetooth cuando el celular empieza a sonar, abre «Audio Bluetooth» un instante y vuelve a donde estabas.

## 2.9.0 — Audio Bluetooth sin abrir la app de fábrica
- La música del celular suena al darle play, sin abrir la app «Audio Bluetooth» (automático en Clinkway/Autochips).
- Otras marcas: opción para abrir la app de música Bluetooth un momento al conectar el celular.
- El botón ▶ del inicio activa el audio Bluetooth. Diagnóstico Bluetooth.

## 2.8.0 — Primera versión pública
- Proyecto abierto en GitHub (GPL-3.0).
- Avisos de actualización desde GitHub, con descarga directa o código QR.
- *Acerca de*: buscar actualizaciones, estrella en GitHub, donar y reportar problemas.

## 2.7
- Ajustes rediseñados con barra lateral y categorías.
- Modo oscuro / claro / automático.
- Clima (°C/°F) y brillo del mapa.

## 2.1 – 2.6 · StradaOS
- Nuevo nombre e ícono, y compatibilidad con Android moderno (permisos e instalación en Android 7+, música en Android 5+).
- Mapa en vivo con varias fuentes compatibles con Android 4.x, y diagnóstico.
- Botones de Android Auto y CarPlay, y elección del método de conexión del celular.
- Protección contra apps de espejo (EasyConnection) que bloquean el USB.

## 2.0
- Versión universal: asistente inicial, foto del vehículo con quitado de fondo y color de acento.

## 1.0 – 1.9 · Picanto Launcher (prototipo)
- Pantalla de inicio, reproductor con carátula, lectura de la pista por Bluetooth (Autochips) y Android Auto, y compatibilidad con Android 4.1.
