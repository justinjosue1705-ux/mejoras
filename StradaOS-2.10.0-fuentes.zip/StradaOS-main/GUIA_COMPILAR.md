# Cómo obtener el APK (sin instalar nada)

Este proyecto se compila gratis en GitHub Actions. Tardas unos 5 minutos.

## A) APK de prueba (debug)
1. Sube el contenido de esta carpeta a tu repositorio `lordnordic-debug/StradaOS`, rama `main`
   (en GitHub: *Add file → Upload files*, o con `git add . && git commit && git push`).
2. Abre la pestaña **Actions** → **Compilar (debug)** → **Run workflow**.
3. Cuando termine (círculo verde), entra a la ejecución y baja **StradaOS-debug** al final de la página.
4. Descomprime: dentro está `StradaOS-2.10.0-debug.apk`. Pásalo a la pantalla como indica el README.

## B) APK firmado de producción (release)
1. Crea la etiqueta: `git tag v2.10.0 && git push origin v2.10.0`
   (o sube a `main` con la versión nueva; `release.yml` firma con tus secretos de GitHub).
2. El flujo crea el Release con `StradaOS-2.10.0.apk` y actualiza `update.json`.
   Se instala encima de tu versión anterior sin perder la configuración (misma firma).

## Si falla la compilación
Abre el paso en rojo, copia el error y pégalo en el chat para corregirlo.

## Nota
El APK debug usa otro identificador (`.debug`), así que se instala junto a tu StradaOS actual sin reemplazarlo.
