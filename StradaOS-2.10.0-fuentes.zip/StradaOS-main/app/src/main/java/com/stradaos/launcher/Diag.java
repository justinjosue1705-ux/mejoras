package com.stradaos.launcher;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.content.pm.ActivityInfo;
import android.os.Build;
import android.os.Environment;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Exporta las apps de audio/Bluetooth de fábrica para analizar cómo comparten la pista. */
public class Diag {

    static final String[] KEYS = {"bt", "blue", "music", "audio", "media", "radio", "mcu", "car", "avrcp",
            "a2dp", "goc", "syu", "can", "phone", "dial", "aux", "service", "launcher", "setting", "auto", "nav",
            "conn", "usb", "easy", "carbit", "link"};


    // ---- Registro de errores silenciosos -------------------------------------------------------
    // Antes muchos errores se ignoraban sin dejar rastro. Ahora quedan en un registro en memoria
    // (acotado) que se incluye al exportar el diagnóstico (errores.txt). No usa lambdas (API 16).
    private static final int LOG_MAX = 300;
    private static final List<String> ERR_LOG = new ArrayList<String>();
    private static final List<String> ERR_KEYS = new ArrayList<String>();
    private static final Map<String, Integer> ERR_COUNT = new HashMap<String, Integer>();

    /** Anota un error que se iba a ignorar. Seguro de llamar desde cualquier hilo y nunca lanza. */
    public static void log(String tag, Throwable t) {
        try {
            String msg = t == null ? "null" : t.getClass().getSimpleName() + ": " + t.getMessage();
            String key = tag + "|" + msg;
            synchronized (ERR_LOG) {
                if (ERR_COUNT.size() > 2000) ERR_COUNT.clear();   // tope de memoria
                Integer n = ERR_COUNT.get(key);
                int count = n == null ? 1 : n + 1;
                ERR_COUNT.put(key, count);
                if (count > 1) return;   // el mismo error solo se anota una vez (evita llenar el registro)
                if (ERR_LOG.size() >= LOG_MAX) { ERR_LOG.remove(0); ERR_KEYS.remove(0); }
                String when = new SimpleDateFormat("HH:mm:ss", Locale.US).format(new Date());
                ERR_LOG.add(when + " [" + tag + "] " + msg);
                ERR_KEYS.add(key);
            }
            android.util.Log.w("StradaOS", "[" + tag + "] " + msg);
        } catch (Throwable ignored) {
            // el registro nunca debe romper la app
        }
    }

    /** Texto del registro con cuántas veces se repitió cada error. */
    public static String errorsText() {
        StringBuilder sb = new StringBuilder();
        synchronized (ERR_LOG) {
            if (ERR_LOG.isEmpty()) return "Sin errores registrados en esta sesión.";
            for (int i = 0; i < ERR_LOG.size(); i++) {
                Integer n = ERR_COUNT.get(ERR_KEYS.get(i));
                sb.append(ERR_LOG.get(i));
                if (n != null && n > 1) sb.append("  (x").append(n).append(")");
                sb.append('\n');
            }
        }
        return sb.toString();
    }

    /** Devuelve la carpeta donde quedó todo (o un mensaje de error). */
    public static String export(Context c) {
        File out = new File(Environment.getExternalStorageDirectory(), "StradaDiag");
        out.mkdirs();
        PackageManager pm = c.getPackageManager();
        int copied = 0;
        long bytes = 0;
        PrintWriter w = null;
        try {
            w = new PrintWriter(new FileOutputStream(new File(out, "info.txt")));
            w.println("Build: " + Build.MANUFACTURER + " / " + Build.MODEL + " / " + Build.DEVICE + " / " + Build.PRODUCT);
            w.println("Android: " + Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ") " + Build.DISPLAY);
            w.println("Fingerprint: " + Build.FINGERPRINT);
            w.println();
            List<ApplicationInfo> list = pm.getInstalledApplications(0);
            for (ApplicationInfo ai : list) {
                String label = String.valueOf(pm.getApplicationLabel(ai));
                boolean sys = (ai.flags & ApplicationInfo.FLAG_SYSTEM) != 0;
                w.println((sys ? "[sys] " : "[usr] ") + ai.packageName + " | " + label + " | " + ai.sourceDir);
                String key = (ai.packageName + " " + label).toLowerCase(Locale.US);
                boolean want = false;
                for (String k : KEYS) if (key.contains(k)) { want = true; break; }
                if (ai.packageName.startsWith("com.google.") || ai.packageName.equals(c.getPackageName())) want = false;
                if (!want) continue;
                try {
                    PackageInfo pi = pm.getPackageInfo(ai.packageName,
                            PackageManager.GET_SERVICES | PackageManager.GET_RECEIVERS | PackageManager.GET_ACTIVITIES | PackageManager.GET_PROVIDERS);
                    if (pi.services != null) for (ServiceInfo si : pi.services) w.println("      service  " + si.name + (si.exported ? " (exported)" : ""));
                    if (pi.receivers != null) for (ActivityInfo ri : pi.receivers) w.println("      receiver " + ri.name + (ri.exported ? " (exported)" : ""));
                    if (pi.providers != null) for (android.content.pm.ProviderInfo pr : pi.providers) w.println("      provider " + pr.name + " auth=" + pr.authority);
                } catch (Throwable ignored) { }
                File src = new File(ai.sourceDir);
                if (src.length() > 40L * 1024 * 1024) continue;
                bytes += copy(src, new File(out, ai.packageName + ".apk"));
                String base = ai.sourceDir.substring(0, ai.sourceDir.length() - 4);
                File odex = new File(base + ".odex");
                if (odex.exists()) bytes += copy(odex, new File(out, ai.packageName + ".odex"));
                copied++;
            }
        } catch (Throwable e) {
            if (w != null) w.println("ERROR: " + e);
        } finally {
            if (w != null) w.close();
        }
        // Bluetooth: servicios corriendo y eventos recientes (sirve para dar soporte a otras marcas)
        PrintWriter bw = null;
        try {
            bw = new PrintWriter(new FileOutputStream(new File(out, "bluetooth.txt")));
            bw.println("App Bluetooth Clinkway: " + (BtBridge.available(c) ? "sí" : "no") + " · activaciones: " + BtBridge.activations);
            bw.println();
            bw.println("Servicios corriendo ahora (haz el diagnóstico con el celular sonando por Bluetooth):");
            android.app.ActivityManager am = (android.app.ActivityManager) c.getSystemService(Context.ACTIVITY_SERVICE);
            List<android.app.ActivityManager.RunningServiceInfo> rs = am.getRunningServices(300);
            if (rs != null) for (android.app.ActivityManager.RunningServiceInfo r : rs) {
                bw.println("  " + r.service.flattenToShortString() + (r.foreground ? " [primer plano]" : "") + (r.started ? " [iniciado]" : "") + " clientes=" + r.clientCount);
            }
            bw.println();
            bw.println("Eventos Bluetooth de StradaOS:");
            bw.println(BtBridge.logText());
        } catch (Throwable e) {
            if (bw != null) bw.println("ERROR: " + e);
        } finally {
            if (bw != null) bw.close();
        }
        // Errores que antes se ignoraban en silencio
        PrintWriter ew = null;
        try {
            ew = new PrintWriter(new FileOutputStream(new File(out, "errores.txt")));
            ew.println(errorsText());
        } catch (Throwable e) {
            // sin permiso de escritura: el resto del diagnóstico ya quedó guardado
        } finally {
            if (ew != null) ew.close();
        }
        return out.getAbsolutePath() + "  (" + copied + " apps, " + (bytes / 1024 / 1024) + " MB)";
    }

    private static long copy(File a, File b) {
        InputStream in = null;
        OutputStream os = null;
        long n = 0;
        try {
            in = new FileInputStream(a);
            os = new FileOutputStream(b);
            byte[] buf = new byte[65536];
            int r;
            while ((r = in.read(buf)) > 0) { os.write(buf, 0, r); n += r; }
        } catch (Throwable ignored) {
        } finally {
            try { if (in != null) in.close(); } catch (Throwable ignored) { }
            try { if (os != null) os.close(); } catch (Throwable ignored) { }
        }
        return n;
    }
}
